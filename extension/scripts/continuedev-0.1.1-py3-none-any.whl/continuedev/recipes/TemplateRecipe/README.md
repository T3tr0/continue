# TemplateRecipe

This folder is a template that you can copy to create your own recipe.

## How to use this recipe

Explain here what users should know when using your recipe. What inputs does it have and what actions will it perform?
