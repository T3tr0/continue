# ContinueRecipeRecipe

A recipe for building recipes!

## How to use this recipe

This recipe takes a single input, a description of the recipe to be built.
